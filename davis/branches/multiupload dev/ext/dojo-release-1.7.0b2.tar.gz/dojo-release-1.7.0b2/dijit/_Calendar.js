/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define("dijit/_Calendar",["dojo/_base/kernel",".","./Calendar"],function(_1,_2){
_1.deprecated("dijit._Calendar is deprecated","dijit._Calendar moved to dijit.Calendar",1.5);
_2._Calendar=_2.Calendar;
return _2._Calendar;
});
