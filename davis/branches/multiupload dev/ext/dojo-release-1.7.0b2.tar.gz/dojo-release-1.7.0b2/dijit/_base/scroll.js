/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define("dijit/_base/scroll",["dojo/_base/kernel","..","dojo/window"],function(_1,_2){
_2.scrollIntoView=function(_3,_4){
_1.window.scrollIntoView(_3,_4);
};
return _2.scrollIntoView;
});
