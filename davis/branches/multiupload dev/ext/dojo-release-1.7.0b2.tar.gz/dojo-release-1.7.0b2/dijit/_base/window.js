/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define("dijit/_base/window",["dojo/_base/kernel","..","dojo/window"],function(_1,_2){
_2.getDocumentWindow=function(_3){
return _1.window.get(_3);
};
return _2;
});
