require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	"text" : "Yazı:",
	"insertImageTitle" : "Şəkil başlığı əlavə et",
	"set" : "Yönəlt",
	"newWindow" : "Yeni pəncərə",
	"topWindow" : "Üst pəncərə",
	"target" : "Hədəf:",
	"createLinkTitle" : "Köprü başlığı yarat",
	"parentWindow" : "Ana pəncərə",
	"currentWindow" : "Hazırki pəncərə",
	"url" : "URL:"
})
//end v1.x content
);