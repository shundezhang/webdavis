require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Vlastnosti odkazu",
	insertImageTitle: "Vlastnosti obrázku",
	url: "Adresa URL:",
	text: "Popis:",
	target: "Cíl:",
	set: "Nastavit",
	currentWindow: "Aktuální okno",
	parentWindow: "Nadřízené okno",
	topWindow: "Okno nejvyšší úrovně",
	newWindow: "Nové okno"
})

//end v1.x content
);
