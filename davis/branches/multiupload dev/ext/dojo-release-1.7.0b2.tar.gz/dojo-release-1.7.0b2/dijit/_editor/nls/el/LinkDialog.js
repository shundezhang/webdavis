require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Ιδιότητες σύνδεσης",
	insertImageTitle: "Ιδιότητες εικόνας",
	url: "Διεύθυνση URL:",
	text: "Περιγραφή:",
	target: "Προορισμός:",
	set: "Ορισμός",
	currentWindow: "Τρέχον παράθυρο",
	parentWindow: "Γονικό παράθυρο",
	topWindow: "Παράθυρο σε πρώτο πλάνο",
	newWindow: "Νέο παράθυρο"
})

//end v1.x content
);
