require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	'bold': 'Félkövér',
	'copy': 'Másolás',
	'cut': 'Kivágás',
	'delete': 'Törlés',
	'indent': 'Behúzás',
	'insertHorizontalRule': 'Vízszintes vonalzó',
	'insertOrderedList': 'Számozott lista',
	'insertUnorderedList': 'Felsorolásjeles lista',
	'italic': 'Dőlt',
	'justifyCenter': 'Középre igazítás',
	'justifyFull': 'Sorkizárás',
	'justifyLeft': 'Balra igazítás',
	'justifyRight': 'Jobbra igazítás',
	'outdent': 'Negatív behúzás',
	'paste': 'Beillesztés',
	'redo': 'Újra',
	'removeFormat': 'Formázás eltávolítása',
	'selectAll': 'Összes kijelölése',
	'strikethrough': 'Áthúzott',
	'subscript': 'Alsó index',
	'superscript': 'Felső index',
	'underline': 'Aláhúzott',
	'undo': 'Visszavonás',
	'unlink': 'Hivatkozás eltávolítása',
	'createLink': 'Hivatkozás létrehozása',
	'toggleDir': 'Irány váltókapcsoló',
	'insertImage': 'Kép beszúrása',
	'insertTable': 'Táblázat beszúrása/szerkesztése',
	'toggleTableBorder': 'Táblázatszegély ki-/bekapcsolása',
	'deleteTable': 'Táblázat törlése',
	'tableProp': 'Táblázat tulajdonságai',
	'htmlToggle': 'HTML forrás',
	'foreColor': 'Előtérszín',
	'hiliteColor': 'Háttérszín',
	'plainFormatBlock': 'Bekezdés stílusa',
	'formatBlock': 'Bekezdés stílusa',
	'fontSize': 'Betűméret',
	'fontName': 'Betűtípus',
	'tabIndent': 'Tab behúzás',
	"fullScreen": "Váltás teljes képernyőre",
	"viewSource": "HTML forrás megjelenítése",
	"print": "Nyomtatás",
	"newPage": "Új oldal",
	/* Error messages */
	'systemShortcut': 'A(z) "${0}" művelet a böngészőben csak billentyűparancs használatával érhető el. Használja a következőt: ${1}.'
})
//end v1.x content
);
