require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Proprietà collegamento",
	insertImageTitle: "Proprietà immagine",
	url: "URL:",
	text: "Descrizione:",
	target: "Destinazione:",
	set: "Imposta",
	currentWindow: "Finestra corrente",
	parentWindow: "Finestra parent",
	topWindow: "Finestra in primo piano",
	newWindow: "Nuova finestra"
})

//end v1.x content
);
