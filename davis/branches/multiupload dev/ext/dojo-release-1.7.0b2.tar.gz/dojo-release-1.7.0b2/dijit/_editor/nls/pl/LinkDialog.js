require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Właściwości odsyłacza",
	insertImageTitle: "Właściwości obrazu",
	url: "Adres URL:",
	text: "Opis:",
	target: "Cel:",
	set: "Ustaw",
	currentWindow: "Bieżące okno",
	parentWindow: "Okno macierzyste",
	topWindow: "Okno najwyższego poziomu",
	newWindow: "Nowe okno"
})

//end v1.x content
);
