require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Propriedades da ligação",
	insertImageTitle: "Propriedades da imagem",
	url: "URL:",
	text: "Descrição:",
	target: "Destino:",
	set: "Definir",
	currentWindow: "Janela actual",
	parentWindow: "Janela ascendente",
	topWindow: "Janela superior",
	newWindow: "Nova janela"
})

//end v1.x content
);
