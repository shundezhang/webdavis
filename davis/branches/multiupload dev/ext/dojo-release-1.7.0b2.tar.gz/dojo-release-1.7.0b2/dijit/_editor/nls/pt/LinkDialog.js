require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Propriedades de Link",
	insertImageTitle: "Propriedades de Imagem",
	url: "URL:",
	text: "Descrição:",
	target: "Destino:",
	set: "Definir",
	currentWindow: "Janela Atual",
	parentWindow: "Janela Pai",
	topWindow: "Primeira Janela",
	newWindow: "Nova Janela"
})

//end v1.x content
);
