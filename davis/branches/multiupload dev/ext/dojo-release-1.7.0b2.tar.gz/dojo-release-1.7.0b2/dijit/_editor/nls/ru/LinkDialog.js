require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Свойства ссылки",
	insertImageTitle: "Свойства изображения",
	url: "URL:",
	text: "Описание:",
	target: "Целевой объект:",
	set: "Задать",
	currentWindow: "Текущее окно",
	parentWindow: "Родительское окно",
	topWindow: "Верхнее окно",
	newWindow: "Новое окно"
})

//end v1.x content
);
