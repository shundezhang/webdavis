require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Pripojiť vlastnosti",
	insertImageTitle: "Vlastnosti obrázka ",
	url: "URL:",
	text: "Opis:",
	target: "Cieľ:",
	set: "Nastaviť",
	currentWindow: "Aktuálne okno ",
	parentWindow: "Rodičovské okno ",
	topWindow: "Najvrchnejšie okno ",
	newWindow: "Nové okno "
})

//end v1.x content
);
