require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Lastnosti povezave",
	insertImageTitle: "Lastnosti slike",
	url: "URL:",
	text: "Opis:",
	target: "Cilj:",
	set: "Nastavi",
	currentWindow: "Trenutno okno",
	parentWindow: "Nadrejeno okno",
	topWindow: "Okno na vrhu",
	newWindow: "Novo okno"
})
//end v1.x content
);

