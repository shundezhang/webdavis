require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Länkegenskaper",
	insertImageTitle: "Bildegenskaper",
	url: "URL-adress:",
	text: "Beskrivning:",
	target: "Mål:",
	set: "Ange",
	currentWindow: "aktuellt fönster",
	parentWindow: "överordnat fönster",
	topWindow: "översta fönstret",
	newWindow: "nytt fönster"
})

//end v1.x content
);
