require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "คุณสมบัติลิงก์",
	insertImageTitle: "คุณสมบัติอิมเมจ",
	url: "URL:",
	text: "รายละเอียด:",
	target: "เป้าหมาย:",
	set: "ตั้งค่า",
	currentWindow: "หน้าต่างปัจจุบัน",
	parentWindow: "หน้าต่างหลัก",
	topWindow: "หน้าต่างบนสุด",
	newWindow: "หน้าต่างใหม่"
})

//end v1.x content
);
