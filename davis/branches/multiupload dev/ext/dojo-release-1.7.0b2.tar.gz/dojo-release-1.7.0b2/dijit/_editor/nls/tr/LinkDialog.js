require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	createLinkTitle: "Bağlantı Özellikleri",
	insertImageTitle: "Resim Özellikleri",
	url: "URL:",
	text: "Açıklama:",
	target: "Hedef:",
	set: "Ayarla",
	currentWindow: "Geçerli Pencere",
	parentWindow: "Üst Pencere",
	topWindow: "En Üst Pencere",
	newWindow: "Yeni Pencere"
})

//end v1.x content
);
