/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define("dijit/_tree/dndSource",["dojo/_base/kernel","..","../tree/dndSource"],function(_1,_2){
_1.deprecated("dijit._tree.dndSource has been moved to dijit.tree.dndSource, use that instead","","2.0");
_1.getObject("_tree",true,_2);
_2._tree.dndSource=_2.tree.dndSource;
return _2._tree.dndSource;
});
