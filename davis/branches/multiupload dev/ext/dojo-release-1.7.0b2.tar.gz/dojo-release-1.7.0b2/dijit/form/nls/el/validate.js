require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	invalidMessage: "Η τιμή που καταχωρήσατε δεν είναι έγκυρη.",
	missingMessage: "Η τιμή αυτή πρέπει απαραίτητα να καθοριστεί.",
	rangeMessage: "Η τιμή αυτή δεν ανήκει στο εύρος έγκυρων τιμών."
})
//end v1.x content
);
