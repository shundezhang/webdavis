require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	invalidMessage: "입력된 값이 올바르지 않습니다.",
	missingMessage: "이 값은 필수입니다.",
	rangeMessage: "이 값은 범위를 벗어납니다."
})
//end v1.x content
);
