require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	invalidMessage: "ค่าที่ป้อนไม่ถูกต้อง",
	missingMessage: "จำเป็นต้องมีค่านี้",
	rangeMessage: "ค่านี้เกินช่วง"
})

//end v1.x content
);
