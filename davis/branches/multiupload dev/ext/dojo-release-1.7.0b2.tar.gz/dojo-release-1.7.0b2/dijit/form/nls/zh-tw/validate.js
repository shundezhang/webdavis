require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	invalidMessage: "輸入的值無效。",
	missingMessage: "必須提供此值。",
	rangeMessage: "此值超出範圍。"
})
//end v1.x content
);
