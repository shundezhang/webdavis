require.built();
/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

define(
//begin v1.x content
({
	loadingState: "กำลังโหลด...",
	errorState: "ขออภัย เกิดข้อผิดพลาด"
})

//end v1.x content
);
